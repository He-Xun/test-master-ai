import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Card,
  Button,
  Table,
  Modal,
  Form,
  Input,
  message,
  Popconfirm,
  Space,
  Tag,
  Radio,
  Switch,
  Divider,
  Collapse,
  InputNumber,
  Tooltip,
  Spin,
  Checkbox,
  Alert,
  Tabs,
  Badge,
  Empty,
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  ExperimentOutlined,
  InfoCircleOutlined,
  ApiOutlined,
  LinkOutlined,
  CloudDownloadOutlined,
  ReloadOutlined,
  CheckOutlined,
  CloseOutlined,
  SearchOutlined,
} from '@ant-design/icons';
import { ApiConfig, ModelConfig, RequestMode } from '../types';
import { apiConfigStorage } from '../utils/storage-simple';
import { testApiConfig, fetchAvailableModels } from '../utils/api';

const { Panel } = Collapse;
const { TabPane } = Tabs;

const ApiConfigManagement: React.FC = () => {
  const { t } = useTranslation();
  const [configs, setConfigs] = useState<ApiConfig[]>([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingConfig, setEditingConfig] = useState<ApiConfig | null>(null);
  const [form] = Form.useForm();
  const [testing, setTesting] = useState<string | null>(null);
  const [fetchingModels, setFetchingModels] = useState(false);
  const [availableModels, setAvailableModels] = useState<Array<{id: string, name: string}>>([]);
  const [modelsPanelVisible, setModelsPanelVisible] = useState(false);
  const [modelSearchTerm, setModelSearchTerm] = useState('');
  const [selectedModels, setSelectedModels] = useState<string[]>([]);

  useEffect(() => {
    loadConfigs();
  }, []);

  const loadConfigs = () => {
    console.log('[ApiConfigManagement] 开始加载配置');
    const loadedConfigs = apiConfigStorage.getAll();
    console.log('[ApiConfigManagement] 加载到的配置:', loadedConfigs);
    setConfigs(loadedConfigs);
  };

  const handleCreate = () => {
    setEditingConfig(null);
    form.resetFields();
    form.setFieldsValue({
      requestMode: 'api',
      models: [
        { id: 'model-1', modelId: 'gpt-4o', name: 'GPT-4o', enabled: true },
      ],
    });
    setAvailableModels([]);
    setModelsPanelVisible(false);
    setIsModalVisible(true);
  };

  const handleEdit = (config: ApiConfig) => {
    setEditingConfig(config);
    form.setFieldsValue({
      ...config,
      models: config.models.length > 0 ? config.models : [
        { id: 'model-1', modelId: 'gpt-4o', name: 'GPT-4o', enabled: true },
      ],
    });
    setAvailableModels([]);
    setModelsPanelVisible(false);
    setIsModalVisible(true);
  };

  const handleDelete = (id: string) => {
    apiConfigStorage.delete(id);
    loadConfigs();
    message.success(t('api.deleteSuccess'));
  };

  const handleTest = async (config: ApiConfig) => {
    setTesting(config.id);
    try {
      const success = await testApiConfig(config);
      if (success) {
        message.success(t('api.testSuccess'));
      } else {
        message.error(t('api.testFailed'));
      }
    } catch (error: any) {
      message.error(`${t('api.testFailed')}: ${error.message}`);
    } finally {
      setTesting(null);
    }
  };

  // 获取可用模型列表
  const handleFetchModels = async () => {
    const baseUrl = form.getFieldValue('baseUrl');
    const apiKey = form.getFieldValue('apiKey');
    const requestMode = form.getFieldValue('requestMode');

    if (requestMode !== 'api') {
      message.warning(t('api.onlyApiModeSupport'));
      return;
    }

    if (!baseUrl || !apiKey) {
      message.warning(t('api.fillBaseUrlAndApiKey'));
      return;
    }

    setFetchingModels(true);
    try {
      const tempConfig: ApiConfig = {
        id: 'temp',
        name: 'temp',
        requestMode: 'api',
        baseUrl,
        apiKey,
        models: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const models = await fetchAvailableModels(tempConfig);
      setAvailableModels(models);
      setModelsPanelVisible(true);
      message.success(t('api.fetchModelsSuccess', { count: models.length }));
    } catch (error: any) {
      message.error(`${t('api.fetchModelsFailed')}: ${error.message}`);
      console.error('获取模型失败:', error);
    } finally {
      setFetchingModels(false);
    }
  };

  // 批量添加选中的模型
  const handleAddSelectedModels = (selectedModelIds: string[]) => {
    const selectedModels = availableModels.filter(model => 
      selectedModelIds.includes(model.id)
    );

    const currentModels = form.getFieldValue('models') || [];
    const newModels = selectedModels.map(model => ({
      id: `model-${Date.now()}-${Math.random()}`,
      modelId: model.id,
      name: model.name,
      enabled: true,
    }));

    // 合并现有模型和新模型，避免重复
    const existingIds = new Set(currentModels.map((m: any) => m.modelId));
    const filteredNewModels = newModels.filter(model => !existingIds.has(model.modelId));

    if (filteredNewModels.length === 0) {
      message.warning(t('api.modelAlreadyExists'));
      return;
    }

    form.setFieldsValue({
      models: [...currentModels, ...filteredNewModels]
    });

    message.success(t('api.modelsAdded', { count: filteredNewModels.length }));
    setSelectedModels([]);
    setModelsPanelVisible(false);
  };

  // 全选/取消全选
  const handleSelectAll = (groupModels: Array<{id: string, name: string}>) => {
    const groupIds = groupModels.map(m => m.id);
    const currentSelected = selectedModels;
    const allSelected = groupIds.every(id => currentSelected.includes(id));
    
    if (allSelected) {
      // 取消选择这个组的所有模型
      setSelectedModels(currentSelected.filter(id => !groupIds.includes(id)));
    } else {
      // 选择这个组的所有模型
      const newSelected = Array.from(new Set([...currentSelected, ...groupIds]));
      setSelectedModels(newSelected);
    }
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      console.log('[ApiConfigManagement] 表单验证通过，数据:', values);
      
      // 确保模型配置有效
      if (!values.models || values.models.length === 0) {
        message.error(t('api.requireAtLeastOneModel'));
        return;
      }

      // 为模型生成ID
      const modelsWithIds = values.models.map((model: any, index: number) => ({
        ...model,
        id: model.id || `model-${Date.now()}-${index}`,
      }));

      const configData = {
        ...values,
        models: modelsWithIds,
      };

      console.log('[ApiConfigManagement] 准备保存的配置数据:', configData);

      if (editingConfig) {
        console.log('[ApiConfigManagement] 更新现有配置:', editingConfig.id);
        const result = apiConfigStorage.update(editingConfig.id, configData);
        if (result) {
          message.success(t('api.updateSuccess'));
          console.log('[ApiConfigManagement] 配置更新成功');
        } else {
          message.error(t('api.updateFailed'));
          console.error('[ApiConfigManagement] 配置更新失败');
        }
      } else {
        console.log('[ApiConfigManagement] 创建新配置');
        const result = apiConfigStorage.create(configData);
        if (result) {
          message.success(t('api.createSuccess'));
          console.log('[ApiConfigManagement] 配置创建成功:', result.id);
        } else {
          message.error(t('api.createFailed'));
          console.error('[ApiConfigManagement] 配置创建失败');
        }
      }

      setIsModalVisible(false);
      loadConfigs();
      
      // 验证数据是否真的保存了
      setTimeout(() => {
        const allConfigs = apiConfigStorage.getAll();
        console.log('[ApiConfigManagement] 保存后验证，当前配置数量:', allConfigs.length);
      }, 100);
      
    } catch (error) {
      console.error('[ApiConfigManagement] 表单验证失败:', error);
    }
  };

  // 模型分组逻辑
  const groupModels = (models: Array<{id: string, name: string}>) => {
    const groups: Record<string, Array<{id: string, name: string}>> = {
      'GPT系列': [],
      'Claude系列': [],
      '开源模型': [],
      '其他模型': []
    };

    models.forEach(model => {
      const name = model.name.toLowerCase();
      if (name.includes('gpt') || name.includes('davinci') || name.includes('babbage') || name.includes('curie')) {
        groups['GPT系列'].push(model);
      } else if (name.includes('claude')) {
        groups['Claude系列'].push(model);
      } else if (name.includes('llama') || name.includes('mistral') || name.includes('qwen') || name.includes('chatglm') || name.includes('baichuan')) {
        groups['开源模型'].push(model);
      } else {
        groups['其他模型'].push(model);
      }
    });

    // 移除空分组
    Object.keys(groups).forEach(key => {
      if (groups[key].length === 0) {
        delete groups[key];
      }
    });

    return groups;
  };

  // 过滤模型
  const filteredModels = availableModels.filter(model =>
    model.name.toLowerCase().includes(modelSearchTerm.toLowerCase()) ||
    model.id.toLowerCase().includes(modelSearchTerm.toLowerCase())
  );

  const groupedModels = groupModels(filteredModels);

  const columns = [
    {
      title: t('api.name'),
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: ApiConfig) => (
        <Space>
          {record.requestMode === 'url' ? <LinkOutlined /> : <ApiOutlined />}
          <span>{text}</span>
        </Space>
      ),
    },
    {
      title: t('api.requestMode'),
      dataIndex: 'requestMode',
      key: 'requestMode',
      render: (mode: RequestMode) => (
        <Tag color={mode === 'url' ? 'blue' : 'green'}>
          {mode === 'url' ? t('api.urlDirectRequest') : t('api.apiInterface')}
        </Tag>
      ),
    },
    {
      title: t('api.configInfo'),
      key: 'config',
      render: (record: ApiConfig) => (
        <div>
          {record.requestMode === 'url' ? (
            <div>
              <div>URL: {record.directUrl}</div>
            </div>
          ) : (
            <div>
              <div>Base URL: {record.baseUrl}</div>
              <div>API Key: {record.apiKey ? t('api.configured') : t('api.notConfigured')}</div>
            </div>
          )}
        </div>
      ),
    },
    {
      title: t('api.modelCount'),
      key: 'modelCount',
      render: (record: ApiConfig) => (
        <Tag color="cyan">
          {record.models.filter(m => m.enabled).length} / {record.models.length}
        </Tag>
      ),
    },
    {
      title: t('common.createdAt'),
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => new Date(date).toLocaleString(),
    },
    {
      title: t('common.actions'),
      key: 'actions',
      render: (_: any, record: ApiConfig) => (
        <Space size="small">
          <Button
            type="primary"
            size="small"
            icon={<ExperimentOutlined />}
            loading={testing === record.id}
            onClick={() => handleTest(record)}
            className="bg-green-500 hover:bg-green-600 border-green-500"
          >
            {t('api.test')}
          </Button>
          <Button
            type="default"
            size="small"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            className="border-blue-300 text-blue-600 hover:bg-blue-50"
          >
            {t('api.edit')}
          </Button>
          <Popconfirm
            title={t('api.confirmDelete')}
            onConfirm={() => handleDelete(record.id)}
            okText={t('common.confirm')}
            cancelText={t('common.cancel')}
          >
            <Button 
              type="default" 
              danger 
              size="small"
              icon={<DeleteOutlined />}
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              {t('api.delete')}
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* 页面头部 */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center">
              <ApiOutlined className="text-white text-xl" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t('api.title')}</h1>
              <p className="text-gray-500 mt-1">{t('api.subtitle')}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{configs.length}</div>
              <div className="text-sm text-gray-500">{t('api.configurations')}</div>
            </div>
            <Button 
              type="primary" 
              icon={<PlusOutlined />} 
              onClick={handleCreate}
              size="large"
              className="bg-gradient-to-r from-blue-500 to-indigo-500 border-none shadow-lg hover:shadow-xl"
            >
              {t('api.add')}
            </Button>
          </div>
        </div>
      </div>

      {/* 配置列表 */}
      <Card className="shadow-sm border-gray-200">
        <Table
          columns={columns}
          dataSource={configs}
          rowKey="id"
          pagination={{ 
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) => t('common.pagination', { start: range[0], end: range[1], total })
          }}
          className="custom-table"
          locale={{
            emptyText: (
              <div className="py-12 text-center">
                <ApiOutlined className="text-4xl text-gray-300 mb-4" />
                <p className="text-gray-500 mb-4">{t('api.noConfigurations')}</p>
                <Button 
                  type="primary" 
                  icon={<PlusOutlined />}
                  onClick={handleCreate}
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 border-none"
                >
                  {t('api.createFirst')}
                </Button>
              </div>
            )
          }}
        />
      </Card>

      <Modal
        title={
          <div className="flex items-center space-x-2">
            <ApiOutlined className="text-blue-500" />
            <span>{editingConfig ? t('api.editConfiguration') : t('api.addConfiguration')}</span>
          </div>
        }
        open={isModalVisible}
        onOk={handleSubmit}
        onCancel={() => setIsModalVisible(false)}
        width={800}
        okText={t('api.save')}
        cancelText={t('api.cancel')}
        okButtonProps={{
          size: 'large',
          className: 'bg-gradient-to-r from-blue-500 to-indigo-500 border-none'
        }}
        cancelButtonProps={{ size: 'large' }}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="name"
            label={t('api.configName')}
            rules={[{ required: true, message: t('api.pleaseEnterConfigName') }]}
          >
            <Input placeholder={t('api.pleaseEnterConfigName')} />
          </Form.Item>

          <Form.Item
            name="requestMode"
            label={t('api.requestMode')}
            rules={[{ required: true, message: t('api.pleaseSelectRequestMode') }]}
          >
            <Radio.Group>
              <Radio value="url">
                <Space>
                  <LinkOutlined />
                  {t('api.urlDirectRequest')}
                  <Tooltip title={t('api.urlDirectRequestTooltip')}>
                    <InfoCircleOutlined />
                  </Tooltip>
                </Space>
              </Radio>
              <Radio value="api">
                <Space>
                  <ApiOutlined />
                  {t('api.apiInterface')}
                  <Tooltip title={t('api.apiInterfaceTooltip')}>
                    <InfoCircleOutlined />
                  </Tooltip>
                </Space>
              </Radio>
            </Radio.Group>
          </Form.Item>

          <Form.Item noStyle shouldUpdate={(prevValues, currentValues) => 
            prevValues.requestMode !== currentValues.requestMode
          }>
            {({ getFieldValue }) => {
              const requestMode = getFieldValue('requestMode');
              
              if (requestMode === 'url') {
                return (
                  <Form.Item
                    name="directUrl"
                    label={t('api.requestUrl')}
                    rules={[
                      { required: true, message: t('api.pleaseEnterRequestUrl') },
                      { type: 'url', message: t('api.pleaseEnterValidUrl') },
                    ]}
                  >
                    <Input placeholder="http://127.0.0.1:8008/req" />
                  </Form.Item>
                );
              } else {
                return (
                  <>
                    <Form.Item
                      name="baseUrl"
                      label={t('api.baseUrl')}
                      rules={[
                        { required: true, message: t('api.pleaseEnterBaseUrl') },
                        { type: 'url', message: t('api.pleaseEnterValidUrl') },
                      ]}
                    >
                      <Input placeholder="https://api.openai.com/v1" />
                    </Form.Item>
                    <Form.Item
                      name="apiKey"
                      label={t('api.apiKey')}
                      rules={[{ required: true, message: t('api.pleaseEnterApiKey') }]}
                    >
                      <Input.Password placeholder={t('api.pleaseEnterApiKey')} />
                    </Form.Item>
                  </>
                );
              }
            }}
          </Form.Item>

          <Divider>{t('api.modelConfiguration')}</Divider>

          {/* 自动获取模型按钮 */}
          <Form.Item noStyle shouldUpdate={(prevValues, currentValues) => 
            prevValues.requestMode !== currentValues.requestMode ||
            prevValues.baseUrl !== currentValues.baseUrl ||
            prevValues.apiKey !== currentValues.apiKey
          }>
            {({ getFieldValue }) => {
              const requestMode = getFieldValue('requestMode');
              const baseUrl = getFieldValue('baseUrl');
              const apiKey = getFieldValue('apiKey');
              
              if (requestMode === 'api') {
                return (
                  <div className="mb-4">
                    <Space>
                      <Tooltip title="可以自动从API获取可用模型列表，避免手动输入错误。需要先填写Base URL和API Key。">
                        <Button
                          type="primary"
                          icon={<CloudDownloadOutlined />}
                          loading={fetchingModels}
                          onClick={handleFetchModels}
                          disabled={!baseUrl || !apiKey}
                          className="bg-gradient-to-r from-green-500 to-blue-500 border-none"
                        >
                          {t('api.fetchAvailableModels')}
                        </Button>
                      </Tooltip>
                    </Space>
                  </div>
                );
              }
              return null;
            }}
          </Form.Item>

          {/* 可用模型选择面板 */}
          {modelsPanelVisible && availableModels.length > 0 && (
            <Card 
              title={
                <div className="flex items-center justify-between">
                  <Space>
                    <CloudDownloadOutlined className="text-green-500" />
                    <span>选择要添加的模型</span>
                    <Badge count={filteredModels.length} style={{ backgroundColor: '#52c41a' }} />
                  </Space>
                  <Button 
                    type="text" 
                    icon={<CloseOutlined />} 
                    onClick={() => {
                      setModelsPanelVisible(false);
                      setSelectedModels([]);
                      setModelSearchTerm('');
                    }}
                  />
                </div>
              }
              className="mb-4 border-green-200 bg-green-50"
              size="small"
            >
              {/* 搜索栏和操作按钮 */}
              <div className="mb-4 space-y-3">
                <Input
                  placeholder={t('api.searchModels')}
                  prefix={<SearchOutlined />}
                  value={modelSearchTerm}
                  onChange={(e) => setModelSearchTerm(e.target.value)}
                  size="large"
                  allowClear
                />
                
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    {t('api.selectedModels', { selected: selectedModels.length, total: filteredModels.length })}
                  </div>
                  <Space>
                    <Button 
                      size="small" 
                      onClick={() => setSelectedModels([])}
                      disabled={selectedModels.length === 0}
                    >
                      {t('api.clearSelection')}
                    </Button>
                    <Button 
                      type="primary" 
                      size="small"
                      onClick={() => handleAddSelectedModels(selectedModels)}
                      disabled={selectedModels.length === 0}
                      className="bg-green-500 border-green-500"
                    >
                      {t('api.addSelected', { count: selectedModels.length })}
                    </Button>
                  </Space>
                </div>
              </div>

              {/* 分组显示模型 */}
              {Object.keys(groupedModels).length > 0 ? (
                <Tabs defaultActiveKey={Object.keys(groupedModels)[0]} size="small">
                  {Object.entries(groupedModels).map(([groupName, groupModels]) => (
                    <TabPane 
                      tab={
                        <Badge count={groupModels.length} size="small">
                          <span>{groupName}</span>
                        </Badge>
                      } 
                      key={groupName}
                    >
                      <div className="space-y-3">
                        {/* 分组操作 */}
                        <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="text-sm text-gray-600">
                            {groupName} ({t('common.countItems', { count: groupModels.length })})
                          </span>
                          <Button 
                            size="small" 
                            type="link"
                            onClick={() => handleSelectAll(groupModels)}
                          >
                            {groupModels.every(model => selectedModels.includes(model.id)) ? t('api.deselectAll') : t('api.selectAll')}
                          </Button>
                        </div>
                        
                        {/* 模型列表 */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                          {groupModels.map(model => (
                            <div
                              key={model.id}
                              className={`p-2 border rounded cursor-pointer transition-all ${
                                selectedModels.includes(model.id)
                                  ? 'border-green-500 bg-green-50'
                                  : 'border-gray-200 hover:border-green-300 hover:bg-green-25'
                              }`}
                              onClick={() => {
                                if (selectedModels.includes(model.id)) {
                                  setSelectedModels(selectedModels.filter(id => id !== model.id));
                                } else {
                                  setSelectedModels([...selectedModels, model.id]);
                                }
                              }}
                            >
                              <div className="flex items-center space-x-2">
                                <Checkbox 
                                  checked={selectedModels.includes(model.id)}
                                  onChange={() => {}} // 由外层div处理
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="text-sm font-medium text-gray-900 truncate">
                                    {model.name}
                                  </div>
                                  {model.id !== model.name && (
                                    <div className="text-xs text-gray-500 truncate">
                                      ID: {model.id}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </TabPane>
                  ))}
                </Tabs>
              ) : (
                <Empty 
                  description={t('api.noMatchingModels')}
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                />
              )}
            </Card>
          )}

          <Form.List name="models">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Card
                    key={key}
                    size="small"
                    title={
                      <div className="flex items-center justify-between">
                        <span>{t('api.modelNumber', { number: name + 1 })}</span>
                        <div className="flex items-center space-x-2">
                          <Form.Item
                            {...restField}
                            name={[name, 'enabled']}
                            valuePropName="checked"
                            className="mb-0"
                          >
                            <Switch 
                              size="small"
                              checkedChildren={<CheckOutlined />}
                              unCheckedChildren={<CloseOutlined />}
                            />
                          </Form.Item>
                          {fields.length > 1 && (
                            <Button
                              type="text"
                              danger
                              size="small"
                              icon={<DeleteOutlined />}
                              onClick={() => remove(name)}
                            />
                          )}
                        </div>
                      </div>
                    }
                    className="mb-4 border border-gray-200"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <Form.Item
                        {...restField}
                        name={[name, 'modelId']}
                        label={t('api.modelId')}
                        rules={[{ required: true, message: t('api.pleaseEnterModelId') }]}
                      >
                        <Input placeholder="gpt-4o" />
                      </Form.Item>
                      <Form.Item
                        {...restField}
                        name={[name, 'name']}
                        label={t('api.modelName')}
                        rules={[{ required: true, message: t('api.pleaseEnterModelName') }]}
                      >
                        <Input placeholder="GPT-4o" />
                      </Form.Item>
                    </div>
                  </Card>
                ))}
                <Button
                  type="dashed"
                  onClick={() => add({
                    id: `model-${Date.now()}`,
                    modelId: '',
                    name: '',
                    enabled: true,
                  })}
                  block
                  icon={<PlusOutlined />}
                  className="border-gray-300 text-gray-600 hover:border-blue-500 hover:text-blue-500"
                >
                  {t('api.manualAddModel')}
                </Button>
              </>
            )}
          </Form.List>
        </Form>
      </Modal>
    </div>
  );
};

export default ApiConfigManagement; 