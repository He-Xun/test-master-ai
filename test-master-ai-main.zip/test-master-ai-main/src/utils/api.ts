import axios, { AxiosResponse } from 'axios';
import { ApiConfig, OpenAIRequest, OpenAIResponse, ModelConfig } from '../types';

// 自定义错误类
export class ApiError extends Error {
  constructor(message: string, public statusCode?: number) {
    super(message);
    this.name = 'ApiError';
  }
}

// 延迟函数，支持中止信号
export const delay = (ms: number, signal?: AbortSignal): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error('操作已中止'));
      return;
    }
    
    const timeout = setTimeout(resolve, ms);
    
    if (signal) {
      signal.addEventListener('abort', () => {
        clearTimeout(timeout);
        reject(new Error('操作已中止'));
      });
    }
  });
};

// 构建OpenAI格式的请求
export const buildOpenAIRequest = (
  model: string,
  systemPrompt: string,
  userInput: string,
  temperature: number = 0.7,
  maxTokens: number = 2000
): OpenAIRequest => {
  return {
    model,
    messages: [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: userInput,
      },
    ],
    temperature,
    max_tokens: maxTokens,
  };
};

// URL模式请求
export const callDirectUrlAPI = async (
  config: ApiConfig,
  model: string,
  prompt: string,
  userInput: string,
  signal?: AbortSignal
): Promise<string> => {
  if (!config.directUrl) {
    throw new ApiError('URL模式下必须配置请求URL');
  }

  try {
    const requestData = {
      model,
      prompt,
      user_input: userInput,
      temperature: 0.7,
      max_tokens: 2000,
    };

    const response = await axios.post(config.directUrl, requestData, {
      timeout: 30000, // 30秒超时
      signal, // 添加中止信号支持
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // 假设直接URL返回的是简单的文本响应或者包含content字段的对象
    if (typeof response.data === 'string') {
      return response.data;
    } else if (response.data && response.data.content) {
      return response.data.content;
    } else if (response.data && response.data.response) {
      return response.data.response;
    } else if (response.data && response.data.text) {
      return response.data.text;
    } else {
      return JSON.stringify(response.data);
    }
  } catch (error: any) {
    if (axios.isCancel(error) || error.name === 'AbortError') {
      throw new ApiError('请求已被取消');
    }
    if (error.code === 'ECONNABORTED' && error.message.includes('timeout')) {
      throw new ApiError('请求超时（30秒），请检查网络连接或稍后重试');
    }
    if (error.response) {
      const status = error.response.status;
      const message = error.response.data?.error?.message || 
                     error.response.data?.message || 
                     `HTTP ${status} 错误`;
      throw new ApiError(message, status);
    } else if (error.request) {
      throw new ApiError('网络请求失败，请检查网络连接');
    } else {
      throw new ApiError(`请求配置错误: ${error.message}`);
    }
  }
};

// API模式请求（兼容OpenAI和第三方API）
export const callOpenAIAPI = async (
  config: ApiConfig,
  request: OpenAIRequest,
  signal?: AbortSignal
): Promise<OpenAIResponse> => {
  if (!config.baseUrl || !config.apiKey) {
    throw new ApiError('API模式下必须配置baseUrl和apiKey');
  }

  try {
    // 构建请求URL，支持第三方兼容API
    let requestUrl = config.baseUrl;
    
    // 如果baseUrl已经包含完整路径（如 yunwu.ai/v1），直接使用
    // 否则添加标准的 /chat/completions 路径
    if (!requestUrl.includes('/chat/completions') && !requestUrl.includes('/v1')) {
      requestUrl = `${requestUrl.replace(/\/$/, '')}/chat/completions`;
    } else if (requestUrl.includes('/v1') && !requestUrl.includes('/chat/completions')) {
      requestUrl = `${requestUrl.replace(/\/$/, '')}/chat/completions`;
    }
    
    console.log('API请求URL:', requestUrl);
    console.log('API请求数据:', request);

    const response: AxiosResponse<OpenAIResponse> = await axios.post(
      requestUrl,
      request,
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000, // 30秒超时
        signal, // 添加中止信号支持
      }
    );

    return response.data;
  } catch (error: any) {
    if (axios.isCancel(error) || error.name === 'AbortError') {
      throw new ApiError('请求已被取消');
    }
    if (error.code === 'ECONNABORTED' && error.message.includes('timeout')) {
      throw new ApiError('请求超时（30秒），请检查网络连接或稍后重试');
    }
    if (error.response) {
      const status = error.response.status;
      const message = error.response.data?.error?.message || 
                     error.response.data?.message || 
                     `HTTP ${status} 错误`;
      throw new ApiError(message, status);
    } else if (error.request) {
      throw new ApiError('网络请求失败，请检查网络连接');
    } else {
      throw new ApiError(`请求配置错误: ${error.message}`);
    }
  }
};

// 统一的API调用接口
export const callAPI = async (
  config: ApiConfig,
  model: string,
  prompt: string,
  userInput: string,
  signal?: AbortSignal
): Promise<string> => {
  if (config.requestMode === 'url') {
    return await callDirectUrlAPI(config, model, prompt, userInput, signal);
  } else {
    const request = buildOpenAIRequest(model, prompt, userInput);
    const response = await callOpenAIAPI(config, request, signal);
    return extractResponseContent(response);
  }
};

// 提取响应内容
export const extractResponseContent = (response: OpenAIResponse): string => {
  if (response.choices && response.choices.length > 0) {
    return response.choices[0].message.content || '';
  }
  return '';
};

// 获取可用模型列表
export const fetchAvailableModels = async (config: ApiConfig): Promise<Array<{id: string, name: string}>> => {
  if (!config.baseUrl || !config.apiKey) {
    throw new ApiError('获取模型列表需要配置baseUrl和apiKey');
  }

  try {
    // 构建模型列表请求URL
    let requestUrl = config.baseUrl;
    
    // 移除末尾的斜杠并添加 /models 路径
    if (requestUrl.includes('/v1')) {
      requestUrl = `${requestUrl.replace(/\/$/, '')}/models`;
    } else {
      requestUrl = `${requestUrl.replace(/\/$/, '')}/v1/models`;
    }
    
    console.log('获取模型列表URL:', requestUrl);

    const response = await axios.get(requestUrl, {
      headers: {
        'Authorization': `Bearer ${config.apiKey}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    });

    // 处理不同格式的响应
    let models = [];
    
    if (response.data && response.data.data && Array.isArray(response.data.data)) {
      // OpenAI格式: { data: [...] }
      models = response.data.data.map((model: any) => ({
        id: model.id || model.name || model.model || '',
        name: model.id || model.name || model.model || '',
      }));
    } else if (response.data && Array.isArray(response.data.models)) {
      // 某些API格式: { models: [...] }
      models = response.data.models.map((model: any) => ({
        id: model.id || model.name || model.model || '',
        name: model.id || model.name || model.model || '',
      }));
    } else if (response.data && Array.isArray(response.data)) {
      // 直接返回数组格式: [...]
      models = response.data.map((model: any) => ({
        id: model.id || model.name || model.model || model,
        name: model.id || model.name || model.model || model,
      }));
    } else {
      throw new ApiError('无法解析模型列表响应格式');
    }

    // 过滤掉空值并去重
    const validModels = models
      .filter((model: any) => model.id && model.name)
      .filter((model: any, index: number, self: any[]) => 
        self.findIndex(m => m.id === model.id) === index
      );

    console.log('获取到的模型列表:', validModels);
    return validModels;
    
  } catch (error: any) {
    if (error.response) {
      const status = error.response.status;
      const message = error.response.data?.error?.message || 
                     error.response.data?.message || 
                     `获取模型列表失败: HTTP ${status}`;
      throw new ApiError(message, status);
    } else if (error.request) {
      throw new ApiError('网络请求失败，请检查网络连接');
    } else {
      throw new ApiError(`获取模型列表出错: ${error.message}`);
    }
  }
};

// 测试API配置
export const testApiConfig = async (config: ApiConfig): Promise<boolean> => {
  try {
    if (config.requestMode === 'url') {
      // 测试URL模式
      if (!config.directUrl) {
        throw new ApiError('URL模式下必须配置请求URL');
      }
      
      // 使用一个简单的测试请求
      const testModel = config.models.length > 0 ? config.models[0].name : 'test-model';
      await callDirectUrlAPI(config, testModel, '你好', '测试连接');
      return true;
    } else {
      // 测试API模式
      if (!config.baseUrl || !config.apiKey) {
        throw new ApiError('API模式下必须配置baseUrl和apiKey');
      }

      const testRequest = buildOpenAIRequest(
        'gpt-3.5-turbo',
        '你是一个有用的助手。',
        '请回复"连接测试成功"'
      );
      
      await callOpenAIAPI(config, testRequest);
      return true;
    }
  } catch (error) {
    console.error('API配置测试失败:', error);
    return false;
  }
}; 