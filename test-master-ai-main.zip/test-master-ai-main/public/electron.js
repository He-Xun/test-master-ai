// This file is required by electron-builder
// It's a placeholder that gets replaced during the build process
console.log('Electron app starting...'); 